
#ifndef MAIN_H_
#define MAIN_H_

#define NB_COUL 5

#endif //MAIN_H_